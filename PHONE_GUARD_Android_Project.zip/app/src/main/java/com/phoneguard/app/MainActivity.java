package com.phoneguard.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.StatFs;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(13,10,18), PANEL = Color.rgb( thirty(), 24, 40);
    private final int PURPLE = Color.rgb(181,138,255), WHITE = Color.WHITE, MUTED = Color.rgb(190,178,205);
    private LinearLayout root;
    private final DecimalFormat fmt = new DecimalFormat("0.0");

    private static int thirty(){ return 30; }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        render();
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void space(LinearLayout box, int h) {
        View v = new View(this); box.addView(v, new LinearLayout.LayoutParams(1,h));
    }
    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(18,16,18,16); c.setBackgroundColor(PANEL);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,8);
        root.addView(c,p); return c;
    }
    private void button(LinearLayout parent, String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(105,70,150)));
        parent.addView(b, new LinearLayout.LayoutParams(-1,-2));
        b.setOnClickListener(v -> action.run());
    }
    private String gb(long bytes){ return fmt.format(bytes / 1073741824.0) + " GB"; }

    private void render() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(BG);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20,22,20,24); scroll.addView(root); setContentView(scroll);

        TextView brand = text("✦  PHONE GUARD",22,PURPLE,true); root.addView(brand);
        root.addView(text("PREMIUM DEVICE CARE",11,MUTED,true));
        space(root,20);
        LinearLayout hero = card();
        hero.addView(text("حالة جهازك",16,MUTED,false));
        hero.addView(text("مركز العناية والأمان",23,WHITE,true));
        hero.addView(text("افحص المؤشرات الأساسية واتخذ إجراءات آمنة لتحسين هاتفك.",13,MUTED,false));
        space(hero,8);
        hero.addView(text("لا نحذف ملفاتك الشخصية ولا ندّعي اكتشاف الفيروسات دون فحص متخصص.",11,MUTED,false));

        StatFs fs = new StatFs(android.os.Environment.getDataDirectory().getPath());
        long total = fs.getTotalBytes(), free = fs.getAvailableBytes(), used = total-free;
        LinearLayout storage = card();
        storage.addView(text("التخزين",18,WHITE,true));
        storage.addView(text("المستخدم: " + gb(used) + " من " + gb(total),15,PURPLE,true));
        storage.addView(text("المتاح: " + gb(free),13,MUTED,false));
        ProgressBar pb = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100); pb.setProgress((int)(100.0*used/Math.max(1,total)));
        storage.addView(pb,new LinearLayout.LayoutParams(-1,12));
        button(storage,"فتح إعدادات التخزين",()->startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)));

        ActivityManager am = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo(); am.getMemoryInfo(mi);
        LinearLayout memory = card();
        memory.addView(text("الذاكرة RAM",18,WHITE,true));
        memory.addView(text("المتاح حالياً: " + gb(mi.availMem) + " من " + gb(mi.totalMem),14,MUTED,false));
        memory.addView(text(mi.lowMemory ? "تنبيه: الذاكرة المتاحة منخفضة" : "لا يوجد تحذير نظامي بانخفاض الذاكرة",13,mi.lowMemory?Color.YELLOW:PURPLE,false));

        BatteryManager bm = (BatteryManager)getSystemService(BATTERY_SERVICE);
        int level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        LinearLayout battery = card();
        battery.addView(text("البطارية",18,WHITE,true));
        battery.addView(text("مستوى الشحن: " + (level>=0?level+"%":"غير متاح"),16,PURPLE,true));
        button(battery,"فتح إعدادات البطارية",()->startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));

        LinearLayout safety = card();
        safety.addView(text("الأمان والتطبيقات",18,WHITE,true));
        safety.addView(text("يمكنك مراجعة التطبيقات والأذونات من إعدادات أندرويد. هذا الإصدار لا يشغّل محرك مضاد فيروسات ولا يستطيع فحص بيانات التطبيقات الخاصة.",13,MUTED,false));
        button(safety,"إدارة التطبيقات المثبتة",()->startActivity(new Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS)));
        button(safety,"فتح Google Play Protect",()->{
            Intent i = new Intent("com.google.android.gms.security.settings");
            try { startActivity(i); } catch(Exception e) { startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS)); }
        });

        LinearLayout cleanup = card();
        cleanup.addView(text("تنظيف آمن",18,WHITE,true));
        cleanup.addView(text("أندرويد لا يسمح لتطبيق عادي بحذف مخلفات التطبيقات الأخرى مباشرة. استخدم أداة النظام لإدارة المساحة ومراجعة الملفات قبل حذفها.",13,MUTED,false));
        button(cleanup,"فتح أداة إدارة المساحة",()->{
            try { startActivity(new Intent("android.os.storage.action.MANAGE_STORAGE")); }
            catch(Exception e) { startActivity(new Intent(Settings.ACTION_STORAGE_SETTINGS)); }
        });

        root.addView(text("PHONE GUARD  •  إصدار أولي 1.0",11,MUTED,false));
    }
}
