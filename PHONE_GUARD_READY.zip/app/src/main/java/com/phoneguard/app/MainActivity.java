package com.phoneguard.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.StatFs;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(13, 10, 18);
    private static final int PANEL = Color.rgb(30, 24, 40);
    private static final int PURPLE = Color.rgb(181, 138, 255);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(190, 178, 205);

    private LinearLayout root;
    private final DecimalFormat fmt = new DecimalFormat("0.0");

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        render();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private void space(LinearLayout parent, int height) {
        View spacer = new View(this);
        parent.addView(spacer, new LinearLayout.LayoutParams(1, height));
    }

    private LinearLayout card() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(18, 16, 18, 16);
        panel.setBackgroundColor(PANEL);
        LinearLayout.LayoutParams params =
            new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, 8, 0, 8);
        root.addView(panel, params);
        return panel;
    }

    private void button(LinearLayout parent, String label, Runnable action) {
        Button control = new Button(this);
        control.setText(label);
        control.setTextColor(WHITE);
        control.setBackgroundTintList(
            android.content.res.ColorStateList.valueOf(Color.rgb(105, 70, 150))
        );
        parent.addView(control, new LinearLayout.LayoutParams(-1, -2));
        control.setOnClickListener(view -> action.run());
    }

    private String gb(long bytes) {
        return fmt.format(bytes / 1073741824.0) + " GB";
    }

    private void openSettings(String action, String fallback) {
        try {
            startActivity(new Intent(action));
        } catch (Exception error) {
            startActivity(new Intent(fallback));
        }
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 22, 20, 24);
        scroll.addView(root);
        setContentView(scroll);

        root.addView(text("✦  PHONE GUARD", 22, PURPLE, true));
        root.addView(text("PREMIUM DEVICE CARE", 11, MUTED, true));
        space(root, 20);

        LinearLayout hero = card();
        hero.addView(text("حالة جهازك", 16, MUTED, false));
        hero.addView(text("مركز العناية والأمان", 23, WHITE, true));
        hero.addView(text(
            "افحص المؤشرات الأساسية واتخذ إجراءات آمنة لتحسين هاتفك.",
            13, MUTED, false
        ));
        space(hero, 8);
        hero.addView(text(
            "لا نحذف ملفاتك الشخصية ولا ندّعي اكتشاف الفيروسات دون فحص متخصص.",
            11, MUTED, false
        ));

        StatFs storageStats =
            new StatFs(android.os.Environment.getDataDirectory().getPath());
        long total = storageStats.getTotalBytes();
        long free = storageStats.getAvailableBytes();
        long used = total - free;

        LinearLayout storage = card();
        storage.addView(text("التخزين", 18, WHITE, true));
        storage.addView(text(
            "المستخدم: " + gb(used) + " من " + gb(total),
            15, PURPLE, true
        ));
        storage.addView(text("المتاح: " + gb(free), 13, MUTED, false));
        ProgressBar progress =
            new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress((int) (100.0 * used / Math.max(1, total)));
        storage.addView(progress, new LinearLayout.LayoutParams(-1, 12));
        button(storage, "فتح إعدادات التخزين",
            () -> openSettings(
                Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
                Settings.ACTION_STORAGE_SETTINGS
            )
        );

        ActivityManager manager =
            (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        manager.getMemoryInfo(memoryInfo);

        LinearLayout memory = card();
        memory.addView(text("الذاكرة RAM", 18, WHITE, true));
        memory.addView(text(
            "المتاح حالياً: " + gb(memoryInfo.availMem) +
            " من " + gb(memoryInfo.totalMem),
            14, MUTED, false
        ));
        memory.addView(text(
            memoryInfo.lowMemory
                ? "تنبيه: الذاكرة المتاحة منخفضة"
                : "لا يوجد تحذير نظامي بانخفاض الذاكرة",
            13, memoryInfo.lowMemory ? Color.YELLOW : PURPLE, false
        ));

        BatteryManager batteryManager =
            (BatteryManager) getSystemService(BATTERY_SERVICE);
        int batteryLevel = batteryManager.getIntProperty(
            BatteryManager.BATTERY_PROPERTY_CAPACITY
        );

        LinearLayout battery = card();
        battery.addView(text("البطارية", 18, WHITE, true));
        battery.addView(text(
            "مستوى الشحن: " +
            (batteryLevel >= 0 ? batteryLevel + "%" : "غير متاح"),
            16, PURPLE, true
        ));
        button(battery, "فتح إعدادات البطارية",
            () -> openSettings(
                Settings.ACTION_BATTERY_SAVER_SETTINGS,
                Settings.ACTION_SETTINGS
            )
        );

        LinearLayout safety = card();
        safety.addView(text("الأمان والتطبيقات", 18, WHITE, true));
        safety.addView(text(
            "راجع التطبيقات والأذونات من إعدادات أندرويد. هذا الإصدار لا يشغّل " +
            "محرك مضاد فيروسات ولا يستطيع فحص بيانات التطبيقات الخاصة.",
            13, MUTED, false
        ));
        button(safety, "إدارة التطبيقات المثبتة",
            () -> openSettings(
                Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS,
                Settings.ACTION_SETTINGS
            )
        );
        button(safety, "إعدادات الأمان",
            () -> openSettings(
                Settings.ACTION_SECURITY_SETTINGS,
                Settings.ACTION_SETTINGS
            )
        );

        LinearLayout cleanup = card();
        cleanup.addView(text("تنظيف آمن", 18, WHITE, true));
        cleanup.addView(text(
            "أندرويد لا يسمح لتطبيق عادي بحذف مخلفات التطبيقات الأخرى مباشرة. " +
            "استخدم إعدادات النظام لإدارة المساحة ومراجعة الملفات قبل حذفها.",
            13, MUTED, false
        ));
        button(cleanup, "فتح إعدادات إدارة المساحة",
            () -> openSettings(
                Settings.ACTION_STORAGE_SETTINGS,
                Settings.ACTION_SETTINGS
            )
        );

        space(root, 12);
        root.addView(text("PHONE GUARD  •  إصدار أولي 1.0", 11, MUTED, false));
    }
}
